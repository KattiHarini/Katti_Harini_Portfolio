"use client"

import { useState, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Upload, Camera, ArrowLeft, CheckCircle, AlertTriangle, Brain, Eye, Zap, BarChart3 } from "lucide-react"
import Link from "next/link"

export default function ImageDetectionDemo() {
  const [selectedImage, setSelectedImage] = useState(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisResult, setAnalysisResult] = useState(null)
  const [analysisProgress, setAnalysisProgress] = useState(0)
  const fileInputRef = useRef(null)

  const handleImageUpload = (event) => {
    const file = event.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setSelectedImage(e.target.result)
        setAnalysisResult(null)
      }
      reader.readAsDataURL(file)
    }
  }

  const analyzeImage = async () => {
    if (!selectedImage) return

    setIsAnalyzing(true)
    setAnalysisProgress(0)

    // Simulate AI analysis with progress
    const progressSteps = [
      { step: 20, message: "Loading CNN model..." },
      { step: 40, message: "Preprocessing image..." },
      { step: 60, message: "Extracting features..." },
      { step: 80, message: "Analyzing patterns..." },
      { step: 100, message: "Generating report..." },
    ]

    for (const { step, message } of progressSteps) {
      await new Promise((resolve) => setTimeout(resolve, 800))
      setAnalysisProgress(step)
    }

    // Simulate analysis result
    const isAuthentic = Math.random() > 0.3 // 70% chance of being authentic
    const confidence = (Math.random() * 20 + 80).toFixed(1) // 80-100% confidence

    setAnalysisResult({
      isAuthentic,
      confidence: Number.parseFloat(confidence),
      details: {
        compressionArtifacts: Math.random() > 0.5,
        edgeConsistency: (Math.random() * 20 + 80).toFixed(1),
        noisePattern: (Math.random() * 30 + 70).toFixed(1),
        metadataIntegrity: Math.random() > 0.3,
        pixelAnalysis: (Math.random() * 25 + 75).toFixed(1),
      },
      processingTime: (Math.random() * 2 + 1).toFixed(2),
    })

    setIsAnalyzing(false)
  }

  const sampleImages = [
    { name: "Authentic Photo", url: "/placeholder.svg?height=150&width=150", authentic: true },
    {
      name: "DeepFake Video",
      url: "/placeholder.svg?height=150&width=150",
      authentic: false,
      description: "AI-generated video with manipulated content.",
    },
    {
      name: "AI Generated Face",
      url: "/placeholder.svg?height=150&width=150",
      authentic: false,
      description: "Synthetically created face using deep learning.",
    },
    { name: "Original Portrait", url: "/placeholder.svg?height=150&width=150", authentic: true },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2 text-blue-600 hover:text-blue-700">
                <ArrowLeft className="h-5 w-5" />
                <span>Back to Portfolio</span>
              </Link>
              <div className="flex items-center space-x-2">
                <Brain className="h-8 w-8 text-blue-600" />
                <div>
                  <div className="text-2xl font-bold text-gray-900">DeepFake Detector</div>
                  <div className="text-sm text-gray-600">Advanced AI Detection</div>
                </div>
              </div>
            </div>

            <Badge className="bg-green-100 text-green-800">CNN Model v2.1</Badge>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Upload Section */}
          <div className="lg:col-span-2">
            <Card className="h-fit">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Upload className="h-5 w-5 mr-2" />
                  DeepFake Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                {!selectedImage ? (
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center">
                    <Camera className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Upload an image or video to analyze</h3>
                    <p className="text-gray-600 mb-4">Our AI will detect if the content is a deepfake or authentic</p>
                    <Button onClick={() => fileInputRef.current?.click()}>
                      <Upload className="h-4 w-4 mr-2" />
                      Choose Image
                    </Button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="relative">
                      <img
                        src={selectedImage || "/placeholder.svg"}
                        alt="Selected for analysis"
                        className="w-full max-h-96 object-contain rounded-lg border"
                      />
                      {analysisResult && (
                        <div className="absolute top-4 right-4">
                          <Badge className={analysisResult.isAuthentic ? "bg-green-500" : "bg-red-500"}>
                            {analysisResult.isAuthentic ? "Authentic" : "Manipulated"}
                          </Badge>
                        </div>
                      )}
                    </div>

                    {isAnalyzing && (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">Analyzing image...</span>
                          <span className="text-sm text-gray-600">{analysisProgress}%</span>
                        </div>
                        <Progress value={analysisProgress} className="w-full" />
                      </div>
                    )}

                    <div className="flex space-x-4">
                      <Button onClick={analyzeImage} disabled={isAnalyzing} className="flex-1">
                        <Brain className="h-4 w-4 mr-2" />
                        {isAnalyzing ? "Analyzing..." : "Analyze Image"}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => {
                          setSelectedImage(null)
                          setAnalysisResult(null)
                        }}
                      >
                        Clear
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Analysis Results */}
            {analysisResult && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    {analysisResult.isAuthentic ? (
                      <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                    ) : (
                      <AlertTriangle className="h-5 w-5 mr-2 text-red-600" />
                    )}
                    Analysis Results
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-4 bg-gray-50 rounded-lg">
                        <div className="text-2xl font-bold text-gray-900">{analysisResult.confidence}%</div>
                        <div className="text-sm text-gray-600">Confidence Level</div>
                      </div>
                      <div className="text-center p-4 bg-gray-50 rounded-lg">
                        <div className="text-2xl font-bold text-gray-900">{analysisResult.processingTime}s</div>
                        <div className="text-sm text-gray-600">Processing Time</div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h4 className="font-semibold text-gray-900">Detailed Analysis:</h4>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                          <span className="text-sm">Edge Consistency</span>
                          <Badge variant="outline">{analysisResult.details.edgeConsistency}%</Badge>
                        </div>

                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                          <span className="text-sm">Noise Pattern</span>
                          <Badge variant="outline">{analysisResult.details.noisePattern}%</Badge>
                        </div>

                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                          <span className="text-sm">Pixel Analysis</span>
                          <Badge variant="outline">{analysisResult.details.pixelAnalysis}%</Badge>
                        </div>

                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                          <span className="text-sm">Metadata Integrity</span>
                          <Badge variant={analysisResult.details.metadataIntegrity ? "default" : "destructive"}>
                            {analysisResult.details.metadataIntegrity ? "Valid" : "Suspicious"}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Model Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Eye className="h-5 w-5 mr-2" />
                  Model Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Architecture</span>
                  <span className="text-sm font-medium">CNN</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Accuracy</span>
                  <span className="text-sm font-medium">96.2%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Training Data</span>
                  <span className="text-sm font-medium">1M+ videos/images</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Framework</span>
                  <span className="text-sm font-medium">TensorFlow</span>
                </div>
              </CardContent>
            </Card>

            {/* Features */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Zap className="h-5 w-5 mr-2" />
                  Key Features
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                    DeepFake video detection
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                    Facial manipulation analysis
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                    AI-generated content identification
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                    Real-time processing
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                    Advanced neural networks
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Sample Images */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2" />
                  Try Sample Images
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  {sampleImages.map((sample, index) => (
                    <div key={index} className="cursor-pointer group" onClick={() => setSelectedImage(sample.url)}>
                      <img
                        src={sample.url || "/placeholder.svg"}
                        alt={sample.name}
                        className="w-full h-20 object-cover rounded border group-hover:border-blue-500 transition-colors"
                      />
                      <div className="text-xs text-center mt-1">
                        <div className="font-medium">{sample.name}</div>
                        <Badge variant={sample.authentic ? "default" : "destructive"} className="text-xs">
                          {sample.authentic ? "Authentic" : "Fake"}
                        </Badge>
                        {sample.description && <div className="text-[0.6rem] text-gray-500">{sample.description}</div>}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
