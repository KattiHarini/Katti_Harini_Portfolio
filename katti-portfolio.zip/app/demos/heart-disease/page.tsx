"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Heart,
  ArrowLeft,
  Activity,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  BarChart3,
  User,
  Stethoscope,
} from "lucide-react"
import Link from "next/link"

export default function HeartDiseaseDemo() {
  const [formData, setFormData] = useState({
    age: "",
    sex: "",
    chestPain: "",
    restingBP: "",
    cholesterol: "",
    fastingBS: "",
    restingECG: "",
    maxHR: "",
    exerciseAngina: "",
    oldpeak: "",
    stSlope: "",
  })

  const [prediction, setPrediction] = useState(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const analyzePrediction = async () => {
    setIsAnalyzing(true)

    // Simulate ML analysis
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Calculate risk based on input values
    let riskScore = 0

    // Age factor
    if (Number.parseInt(formData.age) > 60) riskScore += 20
    else if (Number.parseInt(formData.age) > 45) riskScore += 10

    // Cholesterol factor
    if (Number.parseInt(formData.cholesterol) > 240) riskScore += 25
    else if (Number.parseInt(formData.cholesterol) > 200) riskScore += 15

    // Blood pressure factor
    if (Number.parseInt(formData.restingBP) > 140) riskScore += 20
    else if (Number.parseInt(formData.restingBP) > 120) riskScore += 10

    // Max heart rate factor
    if (Number.parseInt(formData.maxHR) < 100) riskScore += 15

    // Exercise angina
    if (formData.exerciseAngina === "yes") riskScore += 20

    // Chest pain type
    if (formData.chestPain === "typical") riskScore += 25
    else if (formData.chestPain === "atypical") riskScore += 15

    // Add some randomness
    riskScore += Math.random() * 10

    const hasDisease = riskScore > 40
    const confidence = Math.min(95, Math.max(75, 85 + Math.random() * 10))

    setPrediction({
      hasDisease,
      riskScore: Math.min(100, riskScore),
      confidence: confidence.toFixed(1),
      recommendations: hasDisease
        ? [
            "Consult a cardiologist immediately",
            "Consider lifestyle modifications",
            "Regular monitoring required",
            "Medication may be necessary",
          ]
        : [
            "Maintain healthy lifestyle",
            "Regular exercise recommended",
            "Monitor blood pressure",
            "Annual health checkups",
          ],
    })

    setIsAnalyzing(false)
  }

  const isFormValid = () => {
    return Object.values(formData).every((value) => value !== "")
  }

  const samplePatients = [
    {
      name: "John D., 45",
      risk: "Low",
      score: 25,
      status: "Healthy",
    },
    {
      name: "Mary S., 62",
      risk: "High",
      score: 78,
      status: "At Risk",
    },
    {
      name: "Robert K., 38",
      risk: "Medium",
      score: 45,
      status: "Monitor",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2 text-blue-600 hover:text-blue-700">
                <ArrowLeft className="h-5 w-5" />
                <span>Back to Portfolio</span>
              </Link>
              <div className="flex items-center space-x-2">
                <Heart className="h-8 w-8 text-red-600" />
                <div>
                  <div className="text-2xl font-bold text-gray-900">CardioPredict AI</div>
                  <div className="text-sm text-gray-600">Heart Disease Detection System</div>
                </div>
              </div>
            </div>

            <Badge className="bg-red-100 text-red-800">ML Model v3.2</Badge>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Input Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <User className="h-5 w-5 mr-2" />
                  Patient Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="age">Age</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="Enter age"
                      value={formData.age}
                      onChange={(e) => handleInputChange("age", e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="sex">Sex</Label>
                    <select
                      id="sex"
                      className="w-full p-2 border rounded-md"
                      value={formData.sex}
                      onChange={(e) => handleInputChange("sex", e.target.value)}
                    >
                      <option value="">Select sex</option>
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                    </select>
                  </div>

                  <div>
                    <Label htmlFor="chestPain">Chest Pain Type</Label>
                    <select
                      id="chestPain"
                      className="w-full p-2 border rounded-md"
                      value={formData.chestPain}
                      onChange={(e) => handleInputChange("chestPain", e.target.value)}
                    >
                      <option value="">Select type</option>
                      <option value="typical">Typical Angina</option>
                      <option value="atypical">Atypical Angina</option>
                      <option value="nonanginal">Non-Anginal Pain</option>
                      <option value="asymptomatic">Asymptomatic</option>
                    </select>
                  </div>

                  <div>
                    <Label htmlFor="restingBP">Resting Blood Pressure</Label>
                    <Input
                      id="restingBP"
                      type="number"
                      placeholder="mmHg"
                      value={formData.restingBP}
                      onChange={(e) => handleInputChange("restingBP", e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="cholesterol">Cholesterol Level</Label>
                    <Input
                      id="cholesterol"
                      type="number"
                      placeholder="mg/dl"
                      value={formData.cholesterol}
                      onChange={(e) => handleInputChange("cholesterol", e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="fastingBS">Fasting Blood Sugar {">"} 120 mg/dl</Label>
                    <select
                      id="fastingBS"
                      className="w-full p-2 border rounded-md"
                      value={formData.fastingBS}
                      onChange={(e) => handleInputChange("fastingBS", e.target.value)}
                    >
                      <option value="">Select</option>
                      <option value="yes">Yes</option>
                      <option value="no">No</option>
                    </select>
                  </div>

                  <div>
                    <Label htmlFor="maxHR">Maximum Heart Rate</Label>
                    <Input
                      id="maxHR"
                      type="number"
                      placeholder="bpm"
                      value={formData.maxHR}
                      onChange={(e) => handleInputChange("maxHR", e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="exerciseAngina">Exercise Induced Angina</Label>
                    <select
                      id="exerciseAngina"
                      className="w-full p-2 border rounded-md"
                      value={formData.exerciseAngina}
                      onChange={(e) => handleInputChange("exerciseAngina", e.target.value)}
                    >
                      <option value="">Select</option>
                      <option value="yes">Yes</option>
                      <option value="no">No</option>
                    </select>
                  </div>
                </div>

                <Button
                  onClick={analyzePrediction}
                  disabled={!isFormValid() || isAnalyzing}
                  className="w-full bg-red-600 hover:bg-red-700"
                >
                  <Activity className="h-4 w-4 mr-2" />
                  {isAnalyzing ? "Analyzing..." : "Analyze Heart Disease Risk"}
                </Button>
              </CardContent>
            </Card>

            {/* Results */}
            {prediction && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    {prediction.hasDisease ? (
                      <AlertTriangle className="h-5 w-5 mr-2 text-red-600" />
                    ) : (
                      <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                    )}
                    Prediction Results
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid grid-cols-3 gap-4">
                      <div className="text-center p-4 bg-gray-50 rounded-lg">
                        <div
                          className={`text-2xl font-bold ${prediction.hasDisease ? "text-red-600" : "text-green-600"}`}
                        >
                          {prediction.hasDisease ? "High Risk" : "Low Risk"}
                        </div>
                        <div className="text-sm text-gray-600">Prediction</div>
                      </div>

                      <div className="text-center p-4 bg-gray-50 rounded-lg">
                        <div className="text-2xl font-bold text-gray-900">{prediction.confidence}%</div>
                        <div className="text-sm text-gray-600">Confidence</div>
                      </div>

                      <div className="text-center p-4 bg-gray-50 rounded-lg">
                        <div className="text-2xl font-bold text-gray-900">{prediction.riskScore.toFixed(0)}</div>
                        <div className="text-sm text-gray-600">Risk Score</div>
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm font-medium">Risk Level</Label>
                      <Progress value={prediction.riskScore} className="mt-2" />
                      <div className="flex justify-between text-xs text-gray-600 mt-1">
                        <span>Low Risk</span>
                        <span>High Risk</span>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Recommendations:</h4>
                      <ul className="space-y-2">
                        {prediction.recommendations.map((rec, index) => (
                          <li key={index} className="flex items-center text-sm">
                            <div className="w-2 h-2 bg-red-600 rounded-full mr-3"></div>
                            {rec}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Model Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2" />
                  Model Performance
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Accuracy</span>
                  <span className="text-sm font-medium">91.2%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Sensitivity</span>
                  <span className="text-sm font-medium">89.5%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Specificity</span>
                  <span className="text-sm font-medium">92.8%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Training Data</span>
                  <span className="text-sm font-medium">10K patients</span>
                </div>
              </CardContent>
            </Card>

            {/* Features */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Stethoscope className="h-5 w-5 mr-2" />
                  Key Features
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                    Multiple ML algorithms
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                    High accuracy prediction
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                    Risk assessment
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                    Clinical recommendations
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                    Data visualization
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Sample Cases */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2" />
                  Sample Cases
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {samplePatients.map((patient, index) => (
                    <div key={index} className="p-3 bg-gray-50 rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium text-sm">{patient.name}</span>
                        <Badge
                          variant={
                            patient.risk === "Low" ? "default" : patient.risk === "Medium" ? "secondary" : "destructive"
                          }
                        >
                          {patient.risk}
                        </Badge>
                      </div>
                      <div className="flex justify-between text-xs text-gray-600">
                        <span>Risk Score: {patient.score}</span>
                        <span>{patient.status}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
