import { NextResponse } from "next/server"

export async function GET() {
  const projects = [
    {
      id: 1,
      title: "AI-Powered E-Commerce Platform",
      description:
        "A comprehensive full-stack e-commerce solution with machine learning-powered product recommendations, real-time inventory management, and secure payment processing. Features user authentication, admin dashboard, and AI-driven personalization for enhanced shopping experience.",
      technologies: ["React.js", "Node.js", "Python", "TensorFlow", "MongoDB", "Stripe API", "JWT", "Express.js"],
      features: [
        "Machine learning recommendation engine",
        "Real-time inventory tracking system",
        "Secure payment gateway integration",
        "Admin analytics dashboard",
        "Responsive design with modern UI/UX",
        "User authentication and authorization",
      ],
      github: "https://github.com/kattiharini/ecommerce-ai-platform",
      demo: "/demos/ecommerce",
      status: "completed",
      featured: true,
      color: "from-emerald-500 to-teal-600",
    },
    {
      id: 2,
      title: "Deep Fake Detection Using Deep Learning",
      description:
        "Advanced AI application using Convolutional Neural Network (CNN) for detecting deep fake videos and images. Capable of identifying sophisticated AI-generated content and distinguishing between authentic and artificially created media with high accuracy.",
      technologies: ["Python", "TensorFlow", "CNN", "OpenCV", "Flask", "NumPy", "Matplotlib"],
      features: [
        "Deep learning model with 96%+ accuracy for deepfake detection",
        "Real-time video and image analysis capabilities",
        "Advanced facial manipulation detection",
        "Batch processing for multiple media files",
        "Detailed forensic analysis reports",
      ],
      github: "https://github.com/kattiharini/deepfake-detection",
      demo: "/demos/deepfake-detection",
      status: "completed",
      featured: false,
      color: "from-blue-500 to-indigo-600",
    },
    {
      id: 3,
      title: "Heart Disease Detection System",
      description:
        "Machine Learning-based system for early heart disease detection using patient data analysis. Offers potential for early diagnosis and improved patient outcomes through advanced ML algorithms and data visualization.",
      technologies: ["Python", "Scikit-learn", "Pandas", "NumPy", "Matplotlib", "Seaborn", "Jupyter"],
      features: [
        "High accuracy disease prediction (90%+)",
        "Multiple ML algorithms comparison",
        "Interactive data visualization",
        "Patient-friendly interface",
        "Comprehensive health reports",
      ],
      github: "https://github.com/kattiharini/heart-disease-detection",
      demo: "/demos/heart-disease",
      status: "completed",
      featured: false,
      color: "from-red-500 to-pink-600",
    },
  ]

  return NextResponse.json({ projects, total: projects.length })
}
