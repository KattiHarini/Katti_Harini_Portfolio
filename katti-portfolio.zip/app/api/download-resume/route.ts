import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Create a comprehensive resume content
    const resumeContent = `
KATTI HARINI
Full-Stack Developer & Machine Learning Enthusiast
=====================================

CONTACT INFORMATION
📧 Email: kattiharini7@gmail.com
📱 Phone: +91 7207870809
📍 Location: Rayachoty, India

PROFILE SUMMARY
"A Good Engineer is a Person Who Makes a Design That Works With as Few Original Ideas as Possible"

Strong in design and integration with intuitive problem-solving skills. Proficient in JAVA, PYTHON, 
JAVASCRIPT and SQL. Passionate about implementing and launching new projects. Ability to translate 
business requirements into technical solutions. Looking to start my career as an entry-level software 
engineer with a reputed firm driven by technology.

EDUCATION
=========
🎓 B.TECH COMPUTER SCIENCE (2021-2025)
   Sri Venkateswara University, College of Engineering
   CGPA: 8.10

🎓 INTERMEDIATE (2019-2021)
   Padmavathi Junior College
   CGPA: 9.7/10

TECHNICAL SKILLS
===============
Programming Languages: Java, Python, C++, JavaScript
Web Development: HTML5, CSS3, JavaScript, React.js, Node.js
Databases & Tools: SQL, Visual Studio Code, GitHub
Concepts: DSA, OOPS, SDL
Other Skills: Project Management, Leadership, Effective Communication

PROJECTS
========
1. 🛒 AI-Powered E-Commerce Platform
   - Full-stack platform with ML-powered product recommendations
   - Real-time inventory management and secure payment processing
   - Technologies: React.js, Node.js, Python, TensorFlow, MongoDB, Stripe API

2. 🧠 Fake Image Detection Using Deep Learning
   - CNN-based solution for detecting manipulated images
   - Robust detection of subtle image manipulations
   - Technologies: Python, TensorFlow, CNN, OpenCV, Flask

3. ❤️ Heart Disease Detection
   - ML algorithms for early disease diagnosis
   - High accuracy prediction with data visualization
   - Technologies: Python, Scikit-learn, Pandas, NumPy, Matplotlib

ACHIEVEMENTS & CERTIFICATIONS
============================
🏆 NPTEL Certification: Introduction to Internet of Things
🏆 NCC 'A' Certification with A Grade
🏆 SIA GIRLS BN
🥇 Gold Medal in Firing (Rank 1 in Whole Camp)
🥈 Silver 80 Elite and Silver Medal
📅 CATC: XI 17-26 Sept, 2018

LANGUAGES
=========
🗣️ English (Fluent)
🗣️ Hindi (Fluent)  
🗣️ Telugu (Fluent)
🗣️ Tamil (Basics)

INTERESTS
=========
• Technology Innovation
• Machine Learning Research
• Open Source Contribution
• Problem Solving
• Team Leadership

Generated on: ${new Date().toLocaleDateString()}
Contact: kattiharini7@gmail.com | +91 7207870809
`

    return new NextResponse(resumeContent, {
      headers: {
        "Content-Type": "text/plain",
        "Content-Disposition": 'attachment; filename="Katti_Harini_Resume.txt"',
      },
    })
  } catch (error) {
    console.error("Resume download error:", error)
    return NextResponse.json({ error: "Failed to download resume" }, { status: 500 })
  }
}
