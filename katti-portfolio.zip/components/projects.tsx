"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Github, Brain, Heart, ShoppingCart } from "lucide-react"
import { useState, useEffect } from "react"

export function Projects() {
  const [projects, setProjects] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchProjects()
  }, [])

  const fetchProjects = async () => {
    try {
      const response = await fetch("/api/projects")
      const data = await response.json()
      setProjects(data.projects)
    } catch (error) {
      console.error("Failed to fetch projects:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleGithubClick = (url: string) => {
    window.open(url, "_blank", "noopener,noreferrer")
  }

  const handleDemoClick = (url: string) => {
    window.open(url, "_blank", "noopener,noreferrer")
  }

  const getProjectIcon = (title: string) => {
    if (title.includes("E-Commerce")) return <ShoppingCart className="h-8 w-8" />
    if (title.includes("Deep Fake Detection")) return <Brain className="h-8 w-8" />
    if (title.includes("Heart Disease")) return <Heart className="h-8 w-8" />
    return <Brain className="h-8 w-8" />
  }

  if (loading) {
    return (
      <section id="projects" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading projects...</p>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section id="projects" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Featured Projects</h2>
          <p className="text-xl text-gray-600">Showcasing my technical expertise and problem-solving abilities</p>
        </div>

        <div className="space-y-8">
          {projects.map((project, index) => (
            <Card
              key={project.id}
              className="overflow-hidden hover:shadow-xl transition-all duration-300 hover:scale-[1.02]"
            >
              <CardContent className="p-0">
                <div className="md:flex">
                  <div className={`md:w-1/3 bg-gradient-to-br ${project.color} p-8 flex items-center justify-center`}>
                    <div className="text-white text-center">
                      {getProjectIcon(project.title)}
                      <h3 className="text-2xl font-bold mt-4">{project.title}</h3>
                    </div>
                  </div>

                  <div className="md:w-2/3 p-8">
                    <p className="text-gray-600 mb-6 leading-relaxed">{project.description}</p>

                    {project.features && (
                      <div className="mb-6">
                        <h4 className="font-semibold text-gray-900 mb-3">Key Features:</h4>
                        <ul className="space-y-2">
                          {project.features.map((feature, idx) => (
                            <li key={idx} className="flex items-center text-gray-600">
                              <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="mb-6">
                      <h4 className="font-semibold text-gray-900 mb-3">Technologies Used:</h4>
                      <div className="flex flex-wrap gap-2">
                        {project.technologies.map((tech) => (
                          <Badge key={tech} variant="outline" className="text-sm hover:bg-gray-100 transition-colors">
                            {tech}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="flex space-x-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleGithubClick(project.github)}
                        className="hover:scale-105 transition-transform duration-200"
                      >
                        <Github className="mr-2 h-4 w-4" />
                        View Code
                      </Button>
                      <Button
                        size="sm"
                        className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 hover:scale-105 transition-all duration-200"
                        onClick={() => handleDemoClick(project.demo)}
                      >
                        <ExternalLink className="mr-2 h-4 w-4" />
                        Live Demo
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
