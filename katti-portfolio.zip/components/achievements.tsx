"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Award, Medal, Trophy, Star } from "lucide-react"

export function Achievements() {
  const achievements = [
    {
      category: "Certifications",
      icon: <Award className="h-6 w-6" />,
      items: [
        "NPTEL Certification: Introduction to Internet of Things",
        "NCC 'A' Certification with A Grade",
        "5A GIRLS BN",
      ],
      color: "from-blue-500 to-blue-600",
    },
    {
      category: "Awards & Recognition",
      icon: <Medal className="h-6 w-6" />,
      items: [
        "Silver 80 Elite and Silver Medal",
        "Gold Medal in Firing (Rank 1 in Whole Camp)",
        "Duration: Jul - Oct 2023",
      ],
      color: "from-yellow-500 to-orange-600",
    },
    {
      category: "Technical Achievements",
      icon: <Trophy className="h-6 w-6" />,
      items: [
        "High accuracy in Heart Disease detection project",
        "Effective CNN implementation for deepfake detection",
      ],
      color: "from-purple-500 to-purple-600",
    },
  ]

  return (
    <section id="achievements" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Achievements & Recognition</h2>
          <p className="text-xl text-gray-600">Milestones and accomplishments throughout my journey</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {achievements.map((achievement, index) => (
            <Card
              key={achievement.category}
              className="h-full hover:shadow-lg transition-all duration-300 hover:scale-105"
            >
              <CardContent className="p-6">
                <div
                  className={`w-12 h-12 rounded-lg bg-gradient-to-r ${achievement.color} flex items-center justify-center text-white mb-4`}
                >
                  {achievement.icon}
                </div>

                <h3 className="text-xl font-bold text-gray-900 mb-4">{achievement.category}</h3>

                <div className="space-y-3">
                  {achievement.items.map((item, idx) => (
                    <div key={idx} className="flex items-start space-x-2">
                      <Star className="h-4 w-4 text-yellow-500 mt-1 flex-shrink-0" />
                      <span className="text-gray-600 text-sm leading-relaxed">{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:shadow-xl transition-shadow duration-300">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold mb-4">Leadership & Communication</h3>
              <p className="text-lg opacity-90 mb-4">Effective Communication, Teamwork, Time Management</p>
              <div className="flex justify-center space-x-4">
                <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                  Leadership
                </Badge>
                <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                  Team Management
                </Badge>
                <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                  Problem Solving
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
