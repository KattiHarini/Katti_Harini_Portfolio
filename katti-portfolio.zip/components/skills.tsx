"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Code, Database, Globe, Wrench } from "lucide-react"

export function Skills() {
  const skillCategories = [
    {
      title: "Programming Languages",
      icon: <Code className="h-6 w-6" />,
      skills: ["Java", "Python", "C++", "JavaScript"],
      color: "from-blue-500 to-blue-600",
    },
    {
      title: "Web Development",
      icon: <Globe className="h-6 w-6" />,
      skills: ["HTML", "CSS", "JavaScript", "React.js", "Node.js"],
      color: "from-green-500 to-green-600",
    },
    {
      title: "Databases & Tools",
      icon: <Database className="h-6 w-6" />,
      skills: ["SQL", "Visual Studio Code", "GitHub"],
      color: "from-purple-500 to-purple-600",
    },
    {
      title: "Other Skills",
      icon: <Wrench className="h-6 w-6" />,
      skills: ["DSA", "OOPS", "SDL", "Project Management", "Leadership"],
      color: "from-orange-500 to-orange-600",
    },
  ]

  const languages = [
    { name: "English", level: "Fluent" },
    { name: "Hindi", level: "Fluent" },
    { name: "Telugu", level: "Fluent" },
    { name: "Tamil", level: "Basics" },
  ]

  return (
    <section id="skills" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Skills & Expertise</h2>
          <p className="text-xl text-gray-600">Technologies and tools I work with</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {skillCategories.map((category, index) => (
            <Card key={category.title} className="h-full hover:shadow-lg transition-all duration-300 hover:scale-105">
              <CardContent className="p-6">
                <div
                  className={`w-12 h-12 rounded-lg bg-gradient-to-r ${category.color} flex items-center justify-center text-white mb-4`}
                >
                  {category.icon}
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">{category.title}</h3>
                <div className="flex flex-wrap gap-2">
                  {category.skills.map((skill) => (
                    <Badge key={skill} variant="secondary" className="text-sm hover:bg-gray-300 transition-colors">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="hover:shadow-lg transition-shadow duration-300">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Languages</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {languages.map((lang) => (
                <div key={lang.name} className="text-center p-4 hover:bg-gray-50 rounded-lg transition-colors">
                  <div className="font-semibold text-gray-900">{lang.name}</div>
                  <div className="text-sm text-gray-600">{lang.level}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
