"use client"

import { Button } from "@/components/ui/button"
import { Download, Github, Linkedin, Mail, ArrowDown } from "lucide-react"
import { useState } from "react"

export function Hero() {
  const [isDownloading, setIsDownloading] = useState(false)

  const handleDownloadResume = async () => {
    try {
      setIsDownloading(true)
      const response = await fetch("/api/download-resume")

      if (!response.ok) {
        throw new Error("Failed to download resume")
      }

      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = "Katti_Harini_Resume.txt"
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)
    } catch (error) {
      console.error("Download failed:", error)
      alert("Failed to download resume. Please try again.")
    } finally {
      setIsDownloading(false)
    }
  }

  const scrollToProjects = () => {
    document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" })
  }

  const scrollToContact = () => {
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section id="home" className="min-h-screen flex items-center justify-center pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="mb-8">
            <div className="w-48 h-48 mx-auto mb-8 rounded-full bg-gradient-to-br from-blue-400 to-purple-600 p-1 animate-pulse">
              <div className="w-full h-full rounded-full bg-white flex items-center justify-center">
                <span className="text-6xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  KH
                </span>
              </div>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6">
              Katti{" "}
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Harini</span>
            </h1>

            <p className="text-xl md:text-2xl text-gray-600 mb-4 max-w-3xl mx-auto">
              A Good Engineer is a Person Who Makes a Design That Works With as Few Original Ideas as Possible
            </p>

            <p className="text-lg text-gray-500 mb-8 max-w-2xl mx-auto">
              Full-Stack Developer & Machine Learning Enthusiast specializing in Java, Python, and modern web
              technologies
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <Button
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 transform hover:scale-105 transition-all duration-200"
              onClick={handleDownloadResume}
              disabled={isDownloading}
            >
              <Download className="mr-2 h-5 w-5" />
              {isDownloading ? "Downloading..." : "Download Resume"}
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={scrollToProjects}
              className="hover:scale-105 transition-all duration-200 bg-transparent"
            >
              View Projects
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={scrollToContact}
              className="hover:scale-105 transition-all duration-200 bg-transparent"
            >
              Contact Me
            </Button>
          </div>

          <div className="flex justify-center space-x-6 mb-12">
            <a
              href="mailto:kattiharini7@gmail.com"
              className="text-gray-600 hover:text-blue-600 transition-colors transform hover:scale-110 duration-200"
              title="Send Email"
            >
              <Mail className="h-8 w-8" />
            </a>
            <a
              href="https://github.com/kattiharini"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-600 hover:text-blue-600 transition-colors transform hover:scale-110 duration-200"
              title="GitHub Profile"
            >
              <Github className="h-8 w-8" />
            </a>
            <a
              href="https://linkedin.com/in/kattiharini"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-600 hover:text-blue-600 transition-colors transform hover:scale-110 duration-200"
              title="LinkedIn Profile"
            >
              <Linkedin className="h-8 w-8" />
            </a>
          </div>

          <div className="animate-bounce">
            <ArrowDown className="h-6 w-6 mx-auto text-gray-400" />
          </div>
        </div>
      </div>
    </section>
  )
}
