"use client"

import { Card, CardContent } from "@/components/ui/card"
import { GraduationCap, MapPin, Phone, Mail } from "lucide-react"

export function About() {
  const handleEmailClick = () => {
    window.location.href = "mailto:kattiharini7@gmail.com"
  }

  const handlePhoneClick = () => {
    window.location.href = "tel:+917207870809"
  }

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">About Me</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Strong in design and integration with intuitive problem-solving skills. Proficient in JAVA, PYTHON,
            JAVASCRIPT and SQL. Passionate about implementing and launching new projects.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <Card className="hover:shadow-lg transition-shadow duration-300">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Profile Summary</h3>
              <p className="text-gray-600 mb-6">
                Ability to translate business requirements into technical solutions. Looking to start my career as an
                entry-level software engineer with a reputed firm driven by technology.
              </p>

              <div className="space-y-4">
                <div
                  className="flex items-center space-x-3 cursor-pointer hover:bg-gray-50 p-2 rounded-lg transition-colors"
                  onClick={handlePhoneClick}
                >
                  <Phone className="h-5 w-5 text-blue-600" />
                  <span className="text-gray-700">+91 7207870809</span>
                </div>
                <div
                  className="flex items-center space-x-3 cursor-pointer hover:bg-gray-50 p-2 rounded-lg transition-colors"
                  onClick={handleEmailClick}
                >
                  <Mail className="h-5 w-5 text-blue-600" />
                  <span className="text-gray-700">kattiharini7@gmail.com</span>
                </div>
                <div className="flex items-center space-x-3">
                  <MapPin className="h-5 w-5 text-blue-600" />
                  <span className="text-gray-700">Rayachoty, India</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow duration-300">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Education</h3>

              <div className="space-y-6">
                <div className="border-l-4 border-blue-600 pl-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <GraduationCap className="h-5 w-5 text-blue-600" />
                    <span className="text-sm text-gray-500">2021-2025</span>
                  </div>
                  <h4 className="font-semibold text-gray-900">B.TECH COMPUTER SCIENCE</h4>
                  <p className="text-gray-600">Sri Venkateswara University</p>
                  <p className="text-gray-600">College of Engineering</p>
                  <p className="text-sm text-gray-500">CGPA: 8.10</p>
                </div>

                <div className="border-l-4 border-purple-600 pl-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <GraduationCap className="h-5 w-5 text-purple-600" />
                    <span className="text-sm text-gray-500">2019-2021</span>
                  </div>
                  <h4 className="font-semibold text-gray-900">INTERMEDIATE</h4>
                  <p className="text-gray-600">Padmavathi Junior College</p>
                  <p className="text-sm text-gray-500">CGPA: 9.7/10</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
